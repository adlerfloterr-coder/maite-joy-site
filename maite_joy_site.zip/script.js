document.addEventListener('DOMContentLoaded', () => {
    console.log('Site Maitê Joy carregado com sucesso!');
});
